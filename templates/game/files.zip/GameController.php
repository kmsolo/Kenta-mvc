<?php

declare(strict_types=1);

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

/**
 * Landningssida och dokumentation för kortspelet 21.
 * Själva spellogiken (game/play m.m.) läggs till i nästa steg.
 */
#[Route('/game')]
final class GameController extends AbstractController
{
    #[Route('', name: 'game_index', methods: ['GET'])]
    public function index(): Response
    {
        return $this->render('game/index.html.twig');
    }

    #[Route('/doc', name: 'game_doc', methods: ['GET'])]
    public function doc(): Response
    {
        return $this->render('game/doc.html.twig');
    }
}
